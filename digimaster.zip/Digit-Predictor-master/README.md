# Digit-Predictor 🎲🎱
***
### Handwritten digit recognition with CNNs 🕸️🖧
***

In this repo, we've build a TensorFlow.js model to recognize handwritten digits with a convolutional neural network. First, we'll train the classifier by having it “look” at thousands of handwritten digit images and their labels. Then we'll evaluate the classifier's accuracy using test data that the model has never seen.

***
### Connect with me on social media 📲 :-
1. LinkedIn : <a href="https://www.linkedin.com/in/santanu-biswas-1482591a7/">@santanu-biswas-1482591a7</a>
2. Instagram : <a href="https://www.instagram.com/_.santanubiswas._/">@_.santanubiswas._</a>
3. Facebook : <a href="https://www.linkedin.com/in/santanu-biswas-1482591a7/https://www.facebook.com/Neil7rockzz/">@Neil7rockzz</a>

***
Give a star 🌟 if you like it.





